/*TrueOrFalse extends Questions and has the following methods: generateToF
 * This returns a String array with 2 indexes. The first index is the questions, and the second index
 * is the answer, which does not need to be displayed, but can be used to compare the selected answer to.
 * 
 */

import java.util.Random;

public class TrueOrFalse extends Question {
	private static Random rand = new Random();

	public TrueOrFalse(int grade, int numOfQuestions) {

		super(grade, numOfQuestions);
		numOfQuestions = 2;

	}

//Returns a String[] with the first index being the ToF Statement, and the second being the answer.
	public String[] generateToF(int grade) {

		String statement = "";
		String[] TFStatement = new String[2];
		int prompt = rand.nextInt(1);
		int maxNum = 10;
		int halfNum = maxNum/2;
		int floor = 2;
		int firstNum = rand.nextInt(halfNum) + floor;
		int secondNum = rand.nextInt(halfNum) + floor;
		int modifier = rand.nextInt(halfNum) + floor;
		int firstNumMod = 0;
		int secondNumMod = 0;
		String[] names1 = new String[4];
		String[] names2 = new String [3];
		String[] object = new String[4];
		String[] cbody = new String[4];
		String[] cbody2 = new String[4];
		
		
		int name1Roll = rand.nextInt(4);
		int name2Roll = rand.nextInt(3);
		int objectRoll = rand.nextInt(4);
		int cbody1Roll = rand.nextInt(4);
		int cbody2Roll = rand.nextInt(4);

		switch (grade) {
		case 0:
			maxNum = 10;
			names1[0] = "Angela"; names1[1] = "Reiko"; names1[2] = "Joe"; names1[3] = "Ekko";
			names2[0] = "John"; names2[1] = "Ellie"; names2[2] = "Goofy";
			object[0] = "Stars"; object[1] = "Planets"; object[2] = "Rockets"; object[3] = "Moons"; object[4] = "Asteriods";
			cbody[0] = "Earth"; cbody[1] = "Jupiter"; cbody[2] = "Neptune"; cbody[3] = "Mars";
			cbody2[0] ="The Sun"; cbody2[1] = "Pluto"; cbody2[2] = "Uranus"; cbody2[3] = "Venus";

			floor = 0;
			firstNum = rand.nextInt(maxNum - 2) + 2;
			int randomPrompt = rand.nextInt(2);
			if (randomPrompt == 0) {
				secondNum = firstNum - 1;
			} else {
				secondNum = firstNum + 1;
			}

			switch (prompt) {
			case 0:
				 statement = String.format("%s counts %d %s. %s counts %d. %s is right.", names1[name1Roll], firstNum, object[objectRoll].toLowerCase(), names2[name2Roll], secondNum, names1[name1Roll]);
				 break;
			
			case 1:
			  statement = String.format("%s counts %d %s. %s counts %d. %s is right.", names1[name1Roll],firstNum, object[objectRoll].toLowerCase(), names2[name2Roll], secondNum, names2[name2Roll]);
			  break;

			case 2:
				statement = String.format(" %s has %d %s. %s has %d %s. %s has more %s. ", cbody[cbody1Roll], firstNum, object[3].toLowerCase(), cbody2[cbody2Roll], secondNum, object[3].toLowerCase(), cbody[cbody1Roll], object[3].toLowerCase());
				break;

			case 3:
				statement = String.format(" %s has %d %s. %s has %d %s. %s has more %s. ", cbody[cbody1Roll], firstNum, object[3].toLowerCase(), cbody2[cbody2Roll], secondNum, object[3].toLowerCase(), cbody2[cbody2Roll], object[3].toLowerCase());
				break;

			case 4:
				statement = String.format("Our Galaxy has %d %s. The next Galaxy has %d . Our Galaxy has more. ", firstNum, object[objectRoll].toLowerCase(), secondNum, );
				break;

			case 5:
				statement = String.format("Our Galaxy has %d %s. The next Galaxy has %d . The next Galaxy has more. ", firstNum, object[objectRoll].toLowerCase(), secondNum, );
				break;
			}
			 TFStatement[0] = statement;
					 if(prompt == 0) {
						  
						  if(firstNum > secondNum) {
							  TFStatement[1] = "True";
						  } else {
							  TFStatement[1] = "False";
						  }
						  
					  } else if (prompt == 1) {
						  
						  if(secondNum < firstNum) {
							  TFStatement[1] = "True";
						  }  else  {
							  TFStatement[1] = "False";
						  }
						  
					  } else if (prompt == 2) {
						  
						  if(secondNum < firstNum) {
							  TFStatement[1] = "True";
						  }  else  {
							  TFStatement[1] = "False";
						  }
						  
					  } else if (prompt == 3) {
						  
						  if(secondNum > firstNum) {
							  TFStatement[1] = "True";
						  }  else  {
							  TFStatement[1] = "False";
						  }
						  
					  } else if (prompt == 4) {
						  
						  if(secondNum < firstNum) {
							  TFStatement[1] = "True";
						  }  else  {
							  TFStatement[1] = "False";
						  }
						  
					  } else if (prompt == 5) {
						  
						  if(secondNum > firstNum) {
							  TFStatement[1] = "True";
						  }  else  {
							  TFStatement[1] = "False";
						  }
						  
					  }
		
					  break;

		case 1:
		maxNum = 20;
		names1[0] = "Bruce"; names1[1] = "Brandon"; names1[2] = "Eddy"; names1[3] = "Dylan";
		names2[0] = "Ash"; names2[1] = "Mark"; names2[2] = "Vegeta";
		object[0] = "Stars"; object[1] = "Planets"; object[2] = "Rockets"; object[3] = "Moons"; object[4] = "Asteriods";
		cbody[0] = "Ganymede"; cbody[1] = "Jupiter"; cbody[2] = "Neptune"; cbody[3] = "Mars";
		cbody2[0] ="The Sun"; cbody2[1] = "Pluto"; cbody2[2] = "Uranus"; cbody2[3] = "Venus";		
		
		if(firstNum == secondNum) {
			firstNum = rand.nextInt(halfNum) + floor;
		}

		//creates a prompt given random numbers
		  switch(prompt) {
		 	case 0:
			 	statement = String.format("%s can name %d %s. %s can name %d. %s can name more.", names1[name1Roll],firstNum, object[objectRoll].toLowerCase(), names2[name2Roll], secondNum, names1[name1Roll]);
			 	break;

		 	case 1: 
			 	statement = String.format("%s can name %d %s. %s can name %d. %s can name more.", names1[name1Roll],firstNum, object[objectRoll].toLowerCase(), names2[name2Roll], secondNum, names2[name2Roll]);
			 	break;

			case 2:
				statement = String.format(" %s has %d %s floating around it. %s has %d %s. %s has more %s floating around it. ", cbody[cbody1Roll], firstNum, object[4].toLowerCase(), cbody2[cbody2Roll], secondNum, object[4].toLowerCase(), cbody[cbody1Roll], object[4].toLowerCase());
				break;

			case 3:
				statement = String.format(" %s has %d %s floating around it. %s has %d %s. %s has more %s floating around it. ", cbody[cbody1Roll], firstNum, object[4].toLowerCase(), cbody2[cbody2Roll], secondNum, object[4].toLowerCase(), cbody2[cbody2Roll], object[4].toLowerCase());
				break;

			case 4:
				statement = String.format(" %s is %d miles away from Earth. %s is %d miles away from Earth. %s is farther away from Earth . ", cbody[cbody1Roll], firstNum, cbody2[cbody2Roll], secondNum, cbody2[cbody2Roll]);
				break;

			case 5:
				statement = String.format(" %s is %d miles away from Earth. %s is %d miles away from Earth. %s is farther away from Earth . ", cbody[cbody1Roll], firstNum, cbody2[cbody2Roll], secondNum, cbody[cbody1Roll]);
				break;
		

		  }
		  TFStatement[0] = statement;
		  
		  
		  //creates the answer for the statement 
		  if(prompt == 0) {
			  
			  if(firstNum > secondNum) {
				  TFStatement[1] = "True";
			  } else {
				  TFStatement[1] = "False";
			  }
			  
		  } else if (prompt == 1) {
			  
			  if(secondNum > firstNum) {
				  TFStatement[1] = "True";
			  }  else  {
				  TFStatement[1] = "False";
			  }
			  
		  } else if (prompt == 2) {
			  
			  if(secondNum < firstNum) {
				  TFStatement[1] = "True";
			  }  else  {
				  TFStatement[1] = "False";
			  }
			  
		  } else if (prompt == 3) {
			  
			  if(secondNum > firstNum) {
				  TFStatement[1] = "True";
			  }  else  {
				  TFStatement[1] = "False";
			  }
			  
		  } else if (prompt == 4) {
			  
			  if(secondNum > firstNum) {
				  TFStatement[1] = "True";
			  }  else  {
				  TFStatement[1] = "False";
			  }
			  
		  } else if (prompt == 5) {
			  
			  if(secondNum < firstNum) {
				  TFStatement[1] = "True";
			  }  else  {
				  TFStatement[1] = "False";
			  }
			  
		  }
		  break;

		case 2:
			maxNum = 999;
			firstNum = rand.nextInt(maxNum - 200) + 200;
			secondNum = rand.nextInt(maxNum - 100) + 100;
			modifier = rand.nextInt(maxNum - 200) + 200;
		prompt = rand.nextInt(3);
			
		switch(prompt) {
		case 0:
			statement = String.format("%d < %d", firstNum, secondNum);
				break;
		case 1:
			statement = String.format("%d > %d", firstNum, secondNum);
				break;
		case 2:
			statement = String.format("%d = %d", firstNum, secondNum);
				break;
		case 3:
			int multiplier1 = rand.nextInt(10) + 1;
			int multiplier2 = rand.nextInt(10) + 1;
			firstNum = rand.nextInt(20) + 1;
			secondNum = rand.nextInt(20) + 1;			

			statement = String.format("%d x %d > %d x %d", firstNum, multiplier1, secondNum, multiplier2);
			firstNumMod = firstNum * multiplier1;
			secondNumMod = secondNum * multiplier2;
				break;

		case 4:
			int transitionNum = 0;
			int operand;
			
			if(operand == 1 && firstNum < modifier || operand == 3 && firstNum < modifier){
				transitionNum = modifier;
				modifier = firstNum;
				firstNum = transitionNum;

			statement = String.format("%d - %d > %d", firstNum, modifier, secondNum);
			firstNumMod = firstNum - modifier;
				break;
		}
		TFStatement[0] = statement;
		
		  if(prompt == 0) {
			  
			  if(firstNum < secondNum) {
				  TFStatement[1] = "True";
			  } else {
				  TFStatement[1] = "False";
			  }
			  
		  } else if (prompt == 1) {
			  
			  if(firstNum >  secondNum) {
				  TFStatement[1] = "True";
			  }  else  {
				  TFStatement[1] = "False";
			  }
			  
		  } else if (prompt == 2) {
			  if(firstNum == secondNum) {
				  TFStatement[1] = "True";
			  } else {
				  TFStatement[1] = "False";
				  
			  }
		  } else if (prompt == 3) {
			  if(firstNumMod > secondNumMod) {
				  TFStatement[1] = "True";
			  } else {
				  TFStatement[1] = "False";
				  
			  }
		  } else if (prompt == 4) {
			  if(firstNumMod > secondNum) {
				  TFStatement[1] = "True";
			  } else {
				  TFStatement[1] = "False";
				  
			  }
		  } 
		
			
			break;

		case 3:
			prompt = rand.nextInt(2);
			maxNum = 180;
			names1[0] = "Bruce";
			names1[1] = "Brand";
			names1[2] = "Eddy";
			names1[3] = "Dylan";
			object[0] = "a game";
			object[1] = "class";
			object[2] = "store";
			object[3] = "a game";
			int[] minutes = new int[3];

			minutes[0] = rand.nextInt(5) + 10;
			minutes[1] = rand.nextInt(10) + 30;
			minutes[2] = rand.nextInt(20) + 25;
			firstNum = rand.nextInt(maxNum - 10) + 10;

			int minutesRand = rand.nextInt(3);

			int time = rand.nextInt(10) + 1;
			switch (prompt) {

			case 0:
				statement = String.format(
						"%s has to go to %s. It takes %d minutes to get there. It's %d:05. Do they have time to get there if it closes at %d:%d?",
						names1[name1Roll], object[objectRoll].toLowerCase(), firstNum, time,
						(time + 1), minutes[minutesRand]);
				if (firstNum < 60 + minutes[minutesRand]) {
					TFStatement[1] = "True";

				} else {
					TFStatement[1] = "False";
				}
				break;
			case 1:
				firstNum = rand.nextInt(55) + 5;
				statement = String.format(
						"%s has to go to %s. It takes %d minutes to get there. It's %d:05. Do they have time to get there if it closes at %d:%d?",
						names1[name1Roll], object[objectRoll].toLowerCase(), firstNum, time,
						(time + 1), minutes[minutesRand]);
				TFStatement[1] = "True";
				break;

			}

			TFStatement[0] = statement;
			break;

		case 4:

			objectRoll = rand.nextInt(3);
			object[0] = "n obtuse";
			object[1] = " right";
			object[2] = "n acute";

			firstNum = rand.nextInt(179) + 1;

			statement = String.format("If an angle is %d degrees, it's a%s angle.", firstNum, object[objectRoll]);
			TFStatement[0] = statement;

			if (objectRoll == 0) {
				if (firstNum > 90) {
					TFStatement[1] = "True";
				} else {
					TFStatement[1] = "False";
				}
			} else if (objectRoll == 1) {
				if (firstNum == 90) {
					TFStatement[1] = "True";
				} else {
					TFStatement[1] = "False";
				}
			} else if (objectRoll == 2) {
				if (firstNum < 90) {
					TFStatement[1] = "True";
				} else {
					TFStatement[1] = "False";
				}
			}

		}
		return TFStatement;
	}

}
